<?php

namespace BaskelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BaskelBundle extends Bundle
{
}
