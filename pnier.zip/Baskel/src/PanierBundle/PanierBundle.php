<?php

namespace PanierBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PanierBundle extends Bundle
{
}
