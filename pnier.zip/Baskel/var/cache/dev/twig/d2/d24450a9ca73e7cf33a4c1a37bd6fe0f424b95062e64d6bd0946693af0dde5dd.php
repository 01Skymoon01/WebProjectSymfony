<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @Panier/Default/MyCart.html.twig */
class __TwigTemplate_2d1fad9bc1e40ac2433087365263df655f5590c6496028c1032084045a4a6abf extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'container' => [$this, 'block_container'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return "default/front/header.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@Panier/Default/MyCart.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@Panier/Default/MyCart.html.twig"));

        $this->parent = $this->loadTemplate("default/front/header.html.twig", "@Panier/Default/MyCart.html.twig", 2);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_head($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        // line 7
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 11
    public function block_container($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "container"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "container"));

        // line 12
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("jquery-3.4.1.min.js"), "html", null, true);
        echo "\"> </script>

    <script  type=\"application/javascript\" async>
        \$(document).ready(function(){
          //  console.log(\"here jquery\");
        \$(\".remove\").click(function() {
           // console.log(\"remove2\");
           // console.log(\$(this).parent().parent().html());

            \$ref=\$(this).parent().parent().find('.refProduct').val();


            \$.ajax({
                url:'";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("SupprimerItem");
        echo "',
                type: \"GET\",
                data: {
                    'ref' : \$ref
                },
                dataType:\"text\",
                success: function (data)
                {   \$date=\$.parseJSON(data);
                    //console.log(\$date.total);
                    \$( \"#TOTALBABY\").text(\$date.total+'DT');
                    \$(\"#countItems\").text(\$date.articles);
                 alert(\"Produit est bien supprimer\");
                }

            });
            }

        );
            \$( \".qte\" ).change(function() {
               // console.log(\"changed\");

                \$data=\$(this).parent().parent().parent().html();



                //\$data=\$data.hasClass('name').val();

                console.log(\$(this).parent().parent().find('.refProduct').val());
                \$ref=\$(this).parent().parent().find('.refProduct').val();
                \$TotalPrice=\$(this).parent().parent().find('.totalParProduit');
                \$price =\$(this).parent().parent().find('.price ').text();
                \$price= parseFloat(\$price.replace('DT', ''));
                \$qte=\$(this).val();
                \$.ajax({
                    url:'";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ModifierQte");
        echo "',
                    type: \"GET\",
                    data: {
                        'ref' : \$ref,
                        'qte' : \$qte
                    },
                    dataType:\"text\",
                    success: function (data)
                    {
                        console.log(data);
                         console.log(\$price);
                        \$total=\$qte * \$price;
                        \$TotalPrice.text(\$total+'DT');

                        \$date=\$.parseJSON(data);
                      //  console.log(\$date.total);
                        \$( \"#TOTALBABY\").text(\$date.total+'DT');
                        \$(\"#countItems\").text(\$date.articles);

                    }

                });
            });




        });
    </script>
    <!--Shop meta-->
    <ul class=\"tz-ecommerce-meta pull-right\">

        <li class=\"tz-mini-cart\">


            <!--Mini cart-->
            <ul class=\"cart-inner\">
                <li class=\"mini-cart-content\">
                    <div class=\"mini-cart-img\"><img src=\"images/product/product-cart1.png\" alt=\"product search one\"></div>
                    <div class=\"mini-cart-ds\">
                        <h6><a href=\"single-product.html\">Liv Race Day Short</a></h6>
                        <span class=\"mini-cart-meta\">
                                        <a href=\"single-product.html\">\$2650.00</a>
                                        <span class=\"mini-meta\">
                                           <span class=\"mini-color\">Color: <i class=\"orange\"></i></span>
                                           <span class=\"mini-qty\">Qty: 5</span>
                                        </span>
                                    </span>
                    </div>
                    <span class=\"mini-cart-delete\"><img src=\"images/delete.png\" alt=\"delete\"></span>
                </li>
                <li class=\"mini-cart-content\">
                    <div class=\"mini-cart-img\"><img src=\"images/product/product-cart2.png\" alt=\"product search one\"></div>
                    <div class=\"mini-cart-ds\">
                        <h6><a href=\"single-product.html\">City Pedals Sport</a></h6>
                        <span class=\"mini-cart-meta\">
                                        <a href=\"single-product.html\">\$2650.00</a>
                                        <span class=\"mini-meta\">
                                           <span class=\"mini-color\">Color: <i class=\"orange\"></i></span>
                                           <span class=\"mini-qty\">Qty: 5</span>
                                        </span>
                                    </span>
                    </div>
                    <span class=\"mini-cart-delete\"><img src=\"images/delete.png\" alt=\"delete\"></span>
                </li>
                <li class=\"mini-cart-content\">
                    <div class=\"mini-cart-img\"><img src=\"images/product/product-cart3.png\" alt=\"product search one\"></div>
                    <div class=\"mini-cart-ds\">
                        <h6><a href=\"single-product.html\">Gloss</a></h6>
                        <span class=\"mini-cart-meta\">
                                        <a href=\"single-product.html\">\$2650.00</a>
                                        <span class=\"mini-meta\">
                                           <span class=\"mini-color\">Color: <i class=\"orange\"></i></span>
                                           <span class=\"mini-qty\">Qty: 5</span>
                                        </span>
                                    </span>
                    </div>
                    <span class=\"mini-cart-delete\"><img src=\"images/delete.png\" alt=\"delete\"></span>
                </li>
                <li class=\"mini-subtotal\">
                                <span class=\"subtotal-content\">
                                    Subtotal:
                                    <strong class=\"pull-right\">\$1,100.00</strong>
                                </span>
                </li>
                <li class=\"mini-footer\">
                    <a href=\"shop-cart.html\" class=\"view-cart\">View Cart</a>
                    <a href=\"shop-checkout.html\" class=\"check-out\">Checkout</a>
                </li>
            </ul>
            <!--End mini cart-->

        </li>
    </ul>
    <!--End Shop meta-->

    <!--navigation mobi-->
    <button data-target=\".nav-collapse\" class=\"btn-navbar tz_icon_menu\" type=\"button\">
        <i class=\"fa fa-bars\"></i>
    </button>
    <!--End navigation mobi-->
    </div>
    </nav>
    <!--End stat main menu-->

    </header>
    <!--End id tz header-->

    <section class=\"shop-checkout\">
        <div class=\"container\">
            <!--Start Breadcrumbs-->
            <ul class=\"tz-breadcrumbs\">
                <li>
                    <a href=\"#\">Home</a>
                </li>
                <li class=\"current\">
                    Shop Cart
                </li>
            </ul>
            <!--End Breadcrumbs-->
            <h1 class=\"page-title\">Shop Cart</h1>

            <!--Start form table-->
            <form>
                <table class=\"shop_table cart\">
                    <!--Table header-->
                    <thead>
                    <tr>
                        <th class=\"product-remove\">&nbsp;</th>
                        <th class=\"product-thumbnail\">Product</th>
                        <th class=\"product-name\">&nbsp;</th>
                        <th class=\"product-price\">Price</th>
                        <th class=\"product-quantity\">Quantity</th>
                        <th class=\"product-subtotal\">Total</th>
                    </tr>
                    </thead>
                    <!--End table header-->

                    <!--Table body-->
                    ";
        // line 198
        $context["totalHT"] = 0;
        // line 199
        echo "                    ";
        $context["nbr"] = twig_length_filter($this->env, (isset($context["produit"]) ? $context["produit"] : $this->getContext($context, "produit")));
        // line 200
        echo "                    <tbody>
                    ";
        // line 201
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["produit"]) ? $context["produit"] : $this->getContext($context, "produit")));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 202
            echo "

                        <tr class=\"cart_item\">
                            <td class=\"product-remove\">
                                <a class=\"remove\" title=\"Remove this item\"></a>
                                <input type=\"hidden\" class=\"refProduct\" value=\"";
            // line 207
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "refP", []), "html", null, true);
            echo "\">
                            </td>
                            <td class=\"product-thumbnail\">
                                <a href=\"single-product.html\"><img src=\"";
            // line 210
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("front/images/" . $this->getAttribute($context["p"], "image", []))), "html", null, true);
            echo "\" alt=\"cart\" /></a>
                            </td>

                            <td class=\"product-name\">
                                <a href=\"single-product.html\">";
            // line 214
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "nomP", []), "html", null, true);
            echo " </a>
                                <span class=\"color\">
                                    Color: <i class=\"orange\"></i>
                                </span>
                            </td>
                            <td class=\"product-price\">
                                <span class=\"amount price\">";
            // line 220
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "prixP", []), "html", null, true);
            echo "DT</span>
                            </td>

                            <td class=\"product-quantity\">
                                <input type=\"number\" class=\"form-control text-center qte\"  min=\"1\"  max=\"";
            // line 224
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "quantiteP", []), "html", null, true);
            echo "\" value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["panier"]) ? $context["panier"] : $this->getContext($context, "panier")), $this->getAttribute($context["p"], "refP", []), [], "array"), "html", null, true);
            echo "\">

                            </td>

                            <td class=\"product-subtotal\">
                                <span class=\"amount totalParProduit\">";
            // line 229
            echo twig_escape_filter($this->env, ($this->getAttribute($context["p"], "prixP", []) * $this->getAttribute((isset($context["panier"]) ? $context["panier"] : $this->getContext($context, "panier")), $this->getAttribute($context["p"], "refP", []), [], "array")), "html", null, true);
            echo "DT</span>
                            </td>
                        </tr>

                        ";
            // line 233
            $context["totalHT"] = ((isset($context["totalHT"]) ? $context["totalHT"] : $this->getContext($context, "totalHT")) + ($this->getAttribute($context["p"], "prixP", []) * $this->getAttribute((isset($context["panier"]) ? $context["panier"] : $this->getContext($context, "panier")), $this->getAttribute($context["p"], "refP", []), [], "array")));
            // line 234
            echo "                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 235
        echo "
                    <tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Total: </td>
<td id=\"TOTALBABY\">";
        // line 242
        echo twig_escape_filter($this->env, (isset($context["totalHT"]) ? $context["totalHT"] : $this->getContext($context, "totalHT")), "html", null, true);
        echo "DT</td>
                    </tr>
            </form>
            <tr>
                <td class=\"actions\" colspan=\"6\">
                    <a class=\"back-shop\" href=\"";
        // line 247
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("panier_homepage");
        echo "\" ><i class=\"fa fa-angle-left\"></i> BACK TO SHOP</a>
                    <!--a class=\"update-cart\" href=\" path('ValiderCommande' ,{'PrixTotal' : totalHT  ,'date': date('now')|date ,'nbr': nbr}  )\">update cart</a-->

                </td>
            </tr>

            </tbody>
            <!--End table body-->
            </table>

            <!--End form table-->

            <!--Cart attr-->
            <div class=\"row\">
                <div class=\"col-md-6 col-sm-6\">
                    <!--Coupon-->
                    <div class=\"coupon\">
                        <h3>Coupon</h3>
                        <form>
                            <p>Enter your coupon code if you have one.</p>
                            <input type=\"text\" name=\"coupon_code\" class=\"input-text\" id=\"coupon_code\" value=\"\" placeholder=\"Coupon code\">
                            <input type=\"submit\" class=\"button\" name=\"apply_coupon\" value=\"Apply Coupon\">
                        </form>
                    </div>
                    <!--End coupon-->
                </div>
                <div class=\"col-md-6 col-sm-6\">

                    <!--Cart totals-->
                    <div class=\"cart_totals\">
                        <div class=\"cart_totals_inner\">
                            <table>
                                <tbody>
                                <tr class=\"cart-subtotal\">
                                    <th>Subtotal</th>
                                    <td><span class=\"amount\">\$293.00</span></td>
                                </tr>
                                <tr class=\"shipping\">
                                    <th>Shipping and handling</th>
                                    <td>
                                        <form class=\"shop-shipping-calculator\"  method=\"post\">
                                            <p class=\"form-r\">
                                                <input type=\"checkbox\" name=\"rate\" value=\"1\" />
                                                <span>
                                                       Flat Rate:
                                                       <span class=\"price\">
                                                           \$30.00
                                                       </span>
                                                   </span>
                                            </p>
                                            <p class=\"form-r\">
                                                <input type=\"checkbox\" name=\"international\" value=\"1\" />
                                                <span>
                                                       International Delivery:
                                                       <span class=\"price\">
                                                           \$150.00
                                                       </span>
                                                   </span>
                                            </p>
                                            <p class=\"form-r\">
                                                <input type=\"checkbox\" name=\"rate\" value=\"1\" />
                                                <span>
                                                       Local Delivery:
                                                       <span class=\"price\">
                                                           \$90.00
                                                       </span>
                                                   </span>
                                            </p>
                                            <p class=\"form-r\">
                                                <input type=\"checkbox\" name=\"pickup\" value=\"1\" />
                                                <span>Local Pickup (Free)</span>
                                            </p>
                                        </form>
                                    </td>
                                </tr>
                                <tr class=\"order-total\">
                                    <th>Order total</th>
                                    <td><span class=\"amount\">\$293.00</span></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <!--End cart totals-->

                </div>
            </div>
            <!--End cart attr-->
        </div>
    </section>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@Panier/Default/MyCart.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  371 => 247,  363 => 242,  354 => 235,  348 => 234,  346 => 233,  339 => 229,  329 => 224,  322 => 220,  313 => 214,  306 => 210,  300 => 207,  293 => 202,  289 => 201,  286 => 200,  283 => 199,  281 => 198,  139 => 59,  102 => 25,  85 => 12,  76 => 11,  61 => 7,  52 => 6,  30 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("
{% extends 'default/front/header.html.twig' %}



{% block head %}
    {{ parent() }}


{% endblock %}
{% block container %}
    <script src=\"{{ asset('jquery-3.4.1.min.js')}}\"> </script>

    <script  type=\"application/javascript\" async>
        \$(document).ready(function(){
          //  console.log(\"here jquery\");
        \$(\".remove\").click(function() {
           // console.log(\"remove2\");
           // console.log(\$(this).parent().parent().html());

            \$ref=\$(this).parent().parent().find('.refProduct').val();


            \$.ajax({
                url:'{{ path('SupprimerItem') }}',
                type: \"GET\",
                data: {
                    'ref' : \$ref
                },
                dataType:\"text\",
                success: function (data)
                {   \$date=\$.parseJSON(data);
                    //console.log(\$date.total);
                    \$( \"#TOTALBABY\").text(\$date.total+'DT');
                    \$(\"#countItems\").text(\$date.articles);
                 alert(\"Produit est bien supprimer\");
                }

            });
            }

        );
            \$( \".qte\" ).change(function() {
               // console.log(\"changed\");

                \$data=\$(this).parent().parent().parent().html();



                //\$data=\$data.hasClass('name').val();

                console.log(\$(this).parent().parent().find('.refProduct').val());
                \$ref=\$(this).parent().parent().find('.refProduct').val();
                \$TotalPrice=\$(this).parent().parent().find('.totalParProduit');
                \$price =\$(this).parent().parent().find('.price ').text();
                \$price= parseFloat(\$price.replace('DT', ''));
                \$qte=\$(this).val();
                \$.ajax({
                    url:'{{ path('ModifierQte') }}',
                    type: \"GET\",
                    data: {
                        'ref' : \$ref,
                        'qte' : \$qte
                    },
                    dataType:\"text\",
                    success: function (data)
                    {
                        console.log(data);
                         console.log(\$price);
                        \$total=\$qte * \$price;
                        \$TotalPrice.text(\$total+'DT');

                        \$date=\$.parseJSON(data);
                      //  console.log(\$date.total);
                        \$( \"#TOTALBABY\").text(\$date.total+'DT');
                        \$(\"#countItems\").text(\$date.articles);

                    }

                });
            });




        });
    </script>
    <!--Shop meta-->
    <ul class=\"tz-ecommerce-meta pull-right\">

        <li class=\"tz-mini-cart\">


            <!--Mini cart-->
            <ul class=\"cart-inner\">
                <li class=\"mini-cart-content\">
                    <div class=\"mini-cart-img\"><img src=\"images/product/product-cart1.png\" alt=\"product search one\"></div>
                    <div class=\"mini-cart-ds\">
                        <h6><a href=\"single-product.html\">Liv Race Day Short</a></h6>
                        <span class=\"mini-cart-meta\">
                                        <a href=\"single-product.html\">\$2650.00</a>
                                        <span class=\"mini-meta\">
                                           <span class=\"mini-color\">Color: <i class=\"orange\"></i></span>
                                           <span class=\"mini-qty\">Qty: 5</span>
                                        </span>
                                    </span>
                    </div>
                    <span class=\"mini-cart-delete\"><img src=\"images/delete.png\" alt=\"delete\"></span>
                </li>
                <li class=\"mini-cart-content\">
                    <div class=\"mini-cart-img\"><img src=\"images/product/product-cart2.png\" alt=\"product search one\"></div>
                    <div class=\"mini-cart-ds\">
                        <h6><a href=\"single-product.html\">City Pedals Sport</a></h6>
                        <span class=\"mini-cart-meta\">
                                        <a href=\"single-product.html\">\$2650.00</a>
                                        <span class=\"mini-meta\">
                                           <span class=\"mini-color\">Color: <i class=\"orange\"></i></span>
                                           <span class=\"mini-qty\">Qty: 5</span>
                                        </span>
                                    </span>
                    </div>
                    <span class=\"mini-cart-delete\"><img src=\"images/delete.png\" alt=\"delete\"></span>
                </li>
                <li class=\"mini-cart-content\">
                    <div class=\"mini-cart-img\"><img src=\"images/product/product-cart3.png\" alt=\"product search one\"></div>
                    <div class=\"mini-cart-ds\">
                        <h6><a href=\"single-product.html\">Gloss</a></h6>
                        <span class=\"mini-cart-meta\">
                                        <a href=\"single-product.html\">\$2650.00</a>
                                        <span class=\"mini-meta\">
                                           <span class=\"mini-color\">Color: <i class=\"orange\"></i></span>
                                           <span class=\"mini-qty\">Qty: 5</span>
                                        </span>
                                    </span>
                    </div>
                    <span class=\"mini-cart-delete\"><img src=\"images/delete.png\" alt=\"delete\"></span>
                </li>
                <li class=\"mini-subtotal\">
                                <span class=\"subtotal-content\">
                                    Subtotal:
                                    <strong class=\"pull-right\">\$1,100.00</strong>
                                </span>
                </li>
                <li class=\"mini-footer\">
                    <a href=\"shop-cart.html\" class=\"view-cart\">View Cart</a>
                    <a href=\"shop-checkout.html\" class=\"check-out\">Checkout</a>
                </li>
            </ul>
            <!--End mini cart-->

        </li>
    </ul>
    <!--End Shop meta-->

    <!--navigation mobi-->
    <button data-target=\".nav-collapse\" class=\"btn-navbar tz_icon_menu\" type=\"button\">
        <i class=\"fa fa-bars\"></i>
    </button>
    <!--End navigation mobi-->
    </div>
    </nav>
    <!--End stat main menu-->

    </header>
    <!--End id tz header-->

    <section class=\"shop-checkout\">
        <div class=\"container\">
            <!--Start Breadcrumbs-->
            <ul class=\"tz-breadcrumbs\">
                <li>
                    <a href=\"#\">Home</a>
                </li>
                <li class=\"current\">
                    Shop Cart
                </li>
            </ul>
            <!--End Breadcrumbs-->
            <h1 class=\"page-title\">Shop Cart</h1>

            <!--Start form table-->
            <form>
                <table class=\"shop_table cart\">
                    <!--Table header-->
                    <thead>
                    <tr>
                        <th class=\"product-remove\">&nbsp;</th>
                        <th class=\"product-thumbnail\">Product</th>
                        <th class=\"product-name\">&nbsp;</th>
                        <th class=\"product-price\">Price</th>
                        <th class=\"product-quantity\">Quantity</th>
                        <th class=\"product-subtotal\">Total</th>
                    </tr>
                    </thead>
                    <!--End table header-->

                    <!--Table body-->
                    {% set totalHT = 0 %}
                    {% set nbr = produit|length %}
                    <tbody>
                    {% for p in produit %}


                        <tr class=\"cart_item\">
                            <td class=\"product-remove\">
                                <a class=\"remove\" title=\"Remove this item\"></a>
                                <input type=\"hidden\" class=\"refProduct\" value=\"{{ p.refP }}\">
                            </td>
                            <td class=\"product-thumbnail\">
                                <a href=\"single-product.html\"><img src=\"{{ asset('front/images/'~p.image) }}\" alt=\"cart\" /></a>
                            </td>

                            <td class=\"product-name\">
                                <a href=\"single-product.html\">{{ p.nomP }} </a>
                                <span class=\"color\">
                                    Color: <i class=\"orange\"></i>
                                </span>
                            </td>
                            <td class=\"product-price\">
                                <span class=\"amount price\">{{ p.prixP }}DT</span>
                            </td>

                            <td class=\"product-quantity\">
                                <input type=\"number\" class=\"form-control text-center qte\"  min=\"1\"  max=\"{{ p.quantiteP}}\" value=\"{{ panier[p.refP] }}\">

                            </td>

                            <td class=\"product-subtotal\">
                                <span class=\"amount totalParProduit\">{{ p.prixP * panier[p.refP]}}DT</span>
                            </td>
                        </tr>

                        {% set totalHT = totalHT + (p.prixP  * panier[p.refP]) %}
                    {% endfor %}

                    <tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td>Total: </td>
<td id=\"TOTALBABY\">{{ totalHT }}DT</td>
                    </tr>
            </form>
            <tr>
                <td class=\"actions\" colspan=\"6\">
                    <a class=\"back-shop\" href=\"{{  path('panier_homepage') }}\" ><i class=\"fa fa-angle-left\"></i> BACK TO SHOP</a>
                    <!--a class=\"update-cart\" href=\" path('ValiderCommande' ,{'PrixTotal' : totalHT  ,'date': date('now')|date ,'nbr': nbr}  )\">update cart</a-->

                </td>
            </tr>

            </tbody>
            <!--End table body-->
            </table>

            <!--End form table-->

            <!--Cart attr-->
            <div class=\"row\">
                <div class=\"col-md-6 col-sm-6\">
                    <!--Coupon-->
                    <div class=\"coupon\">
                        <h3>Coupon</h3>
                        <form>
                            <p>Enter your coupon code if you have one.</p>
                            <input type=\"text\" name=\"coupon_code\" class=\"input-text\" id=\"coupon_code\" value=\"\" placeholder=\"Coupon code\">
                            <input type=\"submit\" class=\"button\" name=\"apply_coupon\" value=\"Apply Coupon\">
                        </form>
                    </div>
                    <!--End coupon-->
                </div>
                <div class=\"col-md-6 col-sm-6\">

                    <!--Cart totals-->
                    <div class=\"cart_totals\">
                        <div class=\"cart_totals_inner\">
                            <table>
                                <tbody>
                                <tr class=\"cart-subtotal\">
                                    <th>Subtotal</th>
                                    <td><span class=\"amount\">\$293.00</span></td>
                                </tr>
                                <tr class=\"shipping\">
                                    <th>Shipping and handling</th>
                                    <td>
                                        <form class=\"shop-shipping-calculator\"  method=\"post\">
                                            <p class=\"form-r\">
                                                <input type=\"checkbox\" name=\"rate\" value=\"1\" />
                                                <span>
                                                       Flat Rate:
                                                       <span class=\"price\">
                                                           \$30.00
                                                       </span>
                                                   </span>
                                            </p>
                                            <p class=\"form-r\">
                                                <input type=\"checkbox\" name=\"international\" value=\"1\" />
                                                <span>
                                                       International Delivery:
                                                       <span class=\"price\">
                                                           \$150.00
                                                       </span>
                                                   </span>
                                            </p>
                                            <p class=\"form-r\">
                                                <input type=\"checkbox\" name=\"rate\" value=\"1\" />
                                                <span>
                                                       Local Delivery:
                                                       <span class=\"price\">
                                                           \$90.00
                                                       </span>
                                                   </span>
                                            </p>
                                            <p class=\"form-r\">
                                                <input type=\"checkbox\" name=\"pickup\" value=\"1\" />
                                                <span>Local Pickup (Free)</span>
                                            </p>
                                        </form>
                                    </td>
                                </tr>
                                <tr class=\"order-total\">
                                    <th>Order total</th>
                                    <td><span class=\"amount\">\$293.00</span></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <!--End cart totals-->

                </div>
            </div>
            <!--End cart attr-->
        </div>
    </section>


{% endblock %}", "@Panier/Default/MyCart.html.twig", "C:\\wamp64\\www\\WebProjectSymfony\\Baskel\\src\\PanierBundle\\Resources\\views\\Default\\MyCart.html.twig");
    }
}
