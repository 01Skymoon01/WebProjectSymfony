<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @Panier/Default/index.html.twig */
class __TwigTemplate_d3fcb9c9780537c1b919b0b59c9b8fac5e367fe841dd67398a3973f737877798 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'container' => [$this, 'block_container'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "default/front/header.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@Panier/Default/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@Panier/Default/index.html.twig"));

        $this->parent = $this->loadTemplate("default/front/header.html.twig", "@Panier/Default/index.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_container($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "container"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "container"));

        // line 8
        echo "<script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("jquery-3.4.1.min.js"), "html", null, true);
        echo "\"> </script>

<script  type=\"application/javascript\" async>
    \$(document).ready(function(){
        console.log(\"here jquery\");
        \$(\".addcart2\").click(function(){
           // \$(this).hide();
            console.log(\"clicked addcart\");
           \$data=\$(this).parent().parent().parent().html();

            console.log(\$data);

            //\$data=\$data.hasClass('name').val();

            console.log(\$(this).parent().parent().parent().find('.refProduct').val());
            \$ref=\$(this).parent().parent().parent().find('.refProduct').val();
            \$.ajax({
                url:'";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ajouterAuPanier");
        echo "',
                type: \"GET\",
                data: {
                    'ref' : \$ref
                },
                dataType:\"text\",
                success: function (data)
                {
                    console.log(data);
                   // console.log(data.qte);
                    \$date=\$.parseJSON(data);
                    console.log(\$date.etat);
                    if (!(\$date.etat = 1)) {
                    } else {
                        alert(\"Deja ajouter\");
                    }
                    \$(\"#countItems\").text(\$date.articles);
                }

        });

        });




    });
</script>

<div id=\"page\">

    <div id=\"fh5co-product\">
        <!-- Button trigger modal -->




    ";
        // line 62
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["produit"]) ? $context["produit"] : $this->getContext($context, "produit")));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 63
            echo "
        <div class=\"product-item\">
            <div class=\"product-thubnail\">
                <img src=\"";
            // line 66
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("front/images/" . $this->getAttribute($context["p"], "image", []))), "html", null, true);
            echo "\" alt=\"product 3\" />
                <input class=\"imgItem\" type=\"hidden\" name=\"\" value=\"";
            // line 67
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("front/images/" . $this->getAttribute($context["p"], "image", []))), "html", null, true);
            echo "\">
                <div class=\"product-meta\">
                    <a class=\"add-to-cart addcart addcart2\"  >Add to cart</a>
                    <span class=\"quick-view\">

                                                </span>
                </div>
            </div>
            <div class=\"product-infomation desc\">
                <input type=\"hidden\" class=\"refProduct\" value=\"";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "refP", []), "html", null, true);
            echo "\" >
                <h4><a class=\"name \">";
            // line 77
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "nomP", []), "html", null, true);
            echo "</a></h4>
                <span class=\"product-price price\">\$";
            // line 78
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "prixP", []), "html", null, true);
            echo "</span>
                <span class=\"product-attr\">
                                                <i class=\"fa fa-circle light-blue\"></i>
                                                <i class=\"fa fa-circle orange\"></i>
                                                <i class=\"fa fa-circle blueviolet\"></i>
                                                <i class=\"fa fa-circle orange-dark\"></i>
                                                <i class=\"fa fa-circle steelblue\"></i>
                                            </span>
            </div>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 89
        echo "

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@Panier/Default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 89,  154 => 78,  150 => 77,  146 => 76,  134 => 67,  130 => 66,  125 => 63,  121 => 62,  81 => 25,  60 => 8,  51 => 7,  29 => 3,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("

{% extends 'default/front/header.html.twig' %}



{% block container %}
<script src=\"{{ asset('jquery-3.4.1.min.js')}}\"> </script>

<script  type=\"application/javascript\" async>
    \$(document).ready(function(){
        console.log(\"here jquery\");
        \$(\".addcart2\").click(function(){
           // \$(this).hide();
            console.log(\"clicked addcart\");
           \$data=\$(this).parent().parent().parent().html();

            console.log(\$data);

            //\$data=\$data.hasClass('name').val();

            console.log(\$(this).parent().parent().parent().find('.refProduct').val());
            \$ref=\$(this).parent().parent().parent().find('.refProduct').val();
            \$.ajax({
                url:'{{ path('ajouterAuPanier') }}',
                type: \"GET\",
                data: {
                    'ref' : \$ref
                },
                dataType:\"text\",
                success: function (data)
                {
                    console.log(data);
                   // console.log(data.qte);
                    \$date=\$.parseJSON(data);
                    console.log(\$date.etat);
                    if (!(\$date.etat = 1)) {
                    } else {
                        alert(\"Deja ajouter\");
                    }
                    \$(\"#countItems\").text(\$date.articles);
                }

        });

        });




    });
</script>

<div id=\"page\">

    <div id=\"fh5co-product\">
        <!-- Button trigger modal -->




    {% for p in produit %}

        <div class=\"product-item\">
            <div class=\"product-thubnail\">
                <img src=\"{{ asset('front/images/'~p.image)}}\" alt=\"product 3\" />
                <input class=\"imgItem\" type=\"hidden\" name=\"\" value=\"{{ asset('front/images/'~p.image)}}\">
                <div class=\"product-meta\">
                    <a class=\"add-to-cart addcart addcart2\"  >Add to cart</a>
                    <span class=\"quick-view\">

                                                </span>
                </div>
            </div>
            <div class=\"product-infomation desc\">
                <input type=\"hidden\" class=\"refProduct\" value=\"{{ p.refP }}\" >
                <h4><a class=\"name \">{{ p.nomP }}</a></h4>
                <span class=\"product-price price\">\${{ p.prixP }}</span>
                <span class=\"product-attr\">
                                                <i class=\"fa fa-circle light-blue\"></i>
                                                <i class=\"fa fa-circle orange\"></i>
                                                <i class=\"fa fa-circle blueviolet\"></i>
                                                <i class=\"fa fa-circle orange-dark\"></i>
                                                <i class=\"fa fa-circle steelblue\"></i>
                                            </span>
            </div>
        </div>
    {% endfor %}


{% endblock  %}
", "@Panier/Default/index.html.twig", "C:\\wamp64\\www\\WebProjectSymfony\\Baskel\\src\\PanierBundle\\Resources\\views\\Default\\index.html.twig");
    }
}
