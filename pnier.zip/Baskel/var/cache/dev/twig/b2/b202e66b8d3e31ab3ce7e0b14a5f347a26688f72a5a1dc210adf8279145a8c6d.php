<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/front/header.html.twig */
class __TwigTemplate_908bfd27732b947a0033796587e3bc9da3342cd926275fd52ceb94545d4be1e7 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'head' => [$this, 'block_head'],
            'container' => [$this, 'block_container'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/front/header.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/front/header.html.twig"));

        // line 1
        $this->displayBlock('head', $context, $blocks);
        // line 317
        echo "

";
        // line 319
        $this->displayBlock('container', $context, $blocks);
        // line 321
        $this->displayBlock('footer', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 1
    public function block_head($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "head"));

        // line 2
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>Accueil</title>


    <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type='text/css'>
    <link href='";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/font-awesome.min.css"), "html", null, true);
        echo "' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/stylesheet.css"), "html", null, true);
        echo "' rel='stylesheet' type='text/css'>

    <link href='";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/owl.carousel.css"), "html", null, true);
        echo "' rel='stylesheet' type='text/css'>
    <link href='";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/owl.theme.css"), "html", null, true);
        echo "' rel='stylesheet' type='text/css'>
    <link href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/settings.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type='text/css'>
    <link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/custom.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type='text/css'>
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">


</head>
<body>
<div class=\"fh5co-loader\"></div>
<!--Start class site-->

<div class=\"tz-site\">

    <!--Start id tz header-->
    <header id=\"tz-header\" class=\"bk-white\">
        <div class=\"container\">

            <!--Start class header top-->
            <div class=\"header-top\">
                <ul class=\"pull-left\">
                    <li>
                        <a href=\"#\">
                            DT
                            <span class=\"fa fa-angle-down tz-down\"></span>
                        </a>

                    </li>
                    <li>
                        <a href=\"#\">
                            Français

                            <span class=\"fa fa-angle-down tz-down\"></span>
                        </a>
                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"#\">Anglais</a>
                            </li>


                        </ul>
                    </li>
                    <li>
                        <a href=\"#\">Téléphone:   (+216) 53 88 40 67</a>
                    </li>
                </ul>
                <ul class=\"pull-right\">
                    <li>
                        <a href=\"shop-register.html\"> Compte</a>
                    </li>
                    <li>
                        <a href=\"#\">Wishlist</a>
                    </li>
                    <li>
                        <a href=\"shop-cart.html\">Panier</a>
                    </li>
                    <li>
                        <a href=\"shop-checkout.html\">Commande</a>
                    </li>
                    <li>
                        <a href=\"#\">Livraison</a>
                    </li>
                    <li class=\"tz-header-login\">
                        <a href=\"#\">Se Connecter</a>
                        <div class=\"tz-login-form\">
                            <form>
                                <p class=\"form-content\">
                                    <label for=\"username\">pseudo / Email</label>
                                    <input type=\"text\" name=\"username\" id=\"username\" value=\"\">
                                </p>
                                <p class=\"form-content\">
                                    <label for=\"password\">mot de passe</label>
                                    <input type=\"password\" name=\"username\" id=\"password\" value=\"\">
                                </p>
                                <p class=\"form-footer\">
                                    <a href=\"#\">mot de passe oublié?</a>
                                    <button type=\"submit\" class=\"pull-right button_class\">Se connecter</button>
                                </p>
                                <p class=\"form-text\">
                                    vous n'avez pas un compte? <a href=\"shop-register.html\">Inscription</a>
                                </p>
                            </form>
                        </div>
                    </li>

                </ul>
            </div>
            <!--End class header top-->

            <!--Start header content-->
            <div class=\"header-content\">
                <h3 class=\"tz-logo pull-left\"><a href=\"index.html\"><img src=\"";
        // line 107
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/logo horizontal 297px lengeth.png"), "html", null, true);
        echo "\" alt=\"home\" /></a></h3>
                <div class=\"tz-search pull-right\">

                    <!--Start form search-->
                    <form>
                        <label class=\"select-arrow\">
                            <select name=\"category\">
                                <option value=\"\">Catégories</option>
                                <option value=\"#\">Vélos</option>
                                <option value=\"#\">Equipements</option>
                                <option value=\"#\">Vêtements</option>

                            </select>
                        </label>
                        <input type=\"text\" class=\"tz-query\" id=\"tz-query\" value=\"\" placeholder=\"Trouver un produit...\">
                        <button type=\"submit\"></button>
                    </form>
                    <!--End Form search-->

                    <!--live search-->
                    <div class=\"live-search\">
                        <ul>
                            <li>
                                <div class=\"live-img\"><img src=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/product-search1.jpg"), "html", null, true);
        echo "\" alt=\"product search one\"></div>
                                <div class=\"live-search-content\">
                                    <h6><a href=\"single-product.html\">Defy Advanced</a></h6>
                                    <span class=\"live-meta\">
                                            <a href=\"single-product.html\">DT2650.00</a>
                                            <span class=\"product-color\">
                                                <i class=\"light-blue\"></i>
                                                <i class=\"orange\"></i>
                                                <i class=\"orange-dark\"></i>
                                            </span>
                                        </span>
                                </div>
                            </li>
                            <li>
                                <div class=\"live-img\"><img src=\"";
        // line 144
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/product-search2.jpg"), "html", null, true);
        echo "\" alt=\"product search two\"></div>
                                <div class=\"live-search-content\">
                                    <h6><a href=\"single-product.html\">Defy Advanced</a></h6>
                                    <span class=\"live-meta\">
                                            <a href=\"single-product.html\">2650.00 DT</a>
                                            <span class=\"product-color\">
                                                <i class=\"light-blue\"></i>
                                                <i class=\"orange\"></i>
                                                <i class=\"blueviolet\"></i>
                                                <i class=\"orange-dark\"></i>
                                            </span>
                                        </span>
                                </div>
                            </li>
                            <li>
                                <div class=\"live-img\"><img src=\"";
        // line 159
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/p3.jpg"), "html", null, true);
        echo "\" alt=\"product search one\"></div>
                                <div class=\"live-search-content\">
                                    <h6><a href=\"single-product.html\">Defy Advanced</a></h6>
                                    <span class=\"live-meta\">
                                            <a href=\"single-product.html\">2650.00 DT</a>
                                            <span class=\"product-color\">
                                                <i class=\"blueviolet\"></i>
                                                <i class=\"light-blue\"></i>
                                                <i class=\"orange-dark\"></i>
                                                <i class=\"orange\"></i>
                                            </span>
                                        </span>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!--End live search-->
                </div>
            </div>
            <!--End class header content-->
        </div>

        <!--Start main menu -->
        <nav class=\"tz-menu-primary\">
            <div class=\"container\">

                <!--Main Menu-->
                <ul class=\"tz-main-menu pull-left nav-collapse\">
                    <li>
                        <a  href=\"";
        // line 188
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("panier_homepage");
        echo "\" >Accueil</a>
                    </li>


                    <li>
                        <a href=\"shop.html\">Categories</a>


                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"shop-rightsidebar.html\">Velos</a>
                            </li>
                            <li>
                                <a href=\"shop-cart.html\">Equipements</a>
                            </li>
                            <li>
                                <a href=\"shop-cart.html\">Vêtements</a>
                            </li>
                        </ul>

                    </li>

                    <li>
                        <a href=\"shop.html\">Magasin</a>
                    </li>




                    <li>
                        <a href=\"shop.html\">Location</a>




                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"shop-rightsidebar.html\">Velos</a>
                            </li>
                            <li>
                                <a href=\"shop-cart.html\">Equipements</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href=\"#\">
                            Evenements
                            <span class=\"cyan-dark\">Best off!</span>
                        </a>
                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"blog-right.html\">Courses</a>
                            </li>
                            <li>
                                <a href=\"single-blog.html\">Volantaires</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href=\"contact.html\">Contact</a>
                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"contact.html\">Reclamation</a>
                            </li>
                            <li>
                                <a href=\"RDV.html\">Rendez-vous</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!--End Main menu-->
                <div id=\"fh5co-product\">
                <!--Shop meta-->
                <ul class=\"tz-ecommerce-meta pull-right\">
                  <!-----wishlist ------>
                    <li class=\"tz-mini-cart\">
                        <a  href=\"";
        // line 264
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("MyCart");
        echo "\">  <span> <strong id=\"countItems\">";
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["panier"]) ? $context["panier"] : $this->getContext($context, "panier"))), "html", null, true);
        echo "</strong> </span></a>

                        <!--Mini cart-->


                        <!--End mini cart-->

                    </li>
                </ul>
                <!--End Shop meta-->

                <!--navigation mobi-->
                <button data-target=\".nav-collapse\" class=\"btn-navbar tz_icon_menu\" type=\"button\">
                    <i class=\"fa fa-bars\"></i>
                </button>
                <!--End navigation mobi-->
            </div>
        </nav>
        <!--End stat main menu-->

    </header>
    <!--End id tz header-->













    <!--End class site-->

    <script type='text/javascript' src=\"";
        // line 301
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 302
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 303
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/off-canvas.js"), "html", null, true);
        echo "\"></script>
    <!--jQuery Countdow-->
    <script type='text/javascript' src=\"";
        // line 305
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.plugin.min.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 306
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.countdown.min.js"), "html", null, true);
        echo "\"></script>
    <!--End Countdow-->
    <script type='text/javascript' src=\"";
        // line 308
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.parallax-1.1.3.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 309
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/owl.carousel.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 310
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/custom.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src='";
        // line 311
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.themepunch.tools.min.js"), "html", null, true);
        echo "'></script>
    <script type='text/javascript' src='";
        // line 312
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.themepunch.revolution.min.js"), "html", null, true);
        echo "'></script>
    <script type='text/javascript' src='";
        // line 313
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/custom-rs.js"), "html", null, true);
        echo "'></script>
</body>
</html>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 319
    public function block_container($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "container"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "container"));

        // line 320
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 321
    public function block_footer($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 322
        echo "    <!DOCTYPE html>
    <html lang=\"fr\">
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

        <title>Accueil</title>

        <link href=\"";
        // line 330
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type='text/css'>
        <link href='";
        // line 331
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/font-awesome.min.css"), "html", null, true);
        echo "' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
        <link href='";
        // line 333
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/stylesheet.css"), "html", null, true);
        echo "' rel='stylesheet' type='text/css'>

        <link href='";
        // line 335
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/owl.carousel.css"), "html", null, true);
        echo "' rel='stylesheet' type='text/css'>
        <link href='";
        // line 336
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/owl.theme.css"), "html", null, true);
        echo "' rel='stylesheet' type='text/css'>
        <link href=\"";
        // line 337
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/settings.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type='text/css'>
        <link href=\"";
        // line 338
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/css/custom.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type='text/css'>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">


    </head>
    <body>





    <!--Start Footer-->
    <footer class=\"tz-footer\">
        <div class=\"footer-widget\">
            <div class=\"container\">

                <!--Start footer left-->
                <div class=\"footer-left\">
                    <div class=\"contact-info widget\">
                        <h3 class=\"widget-title\">Contacts:</h3>
                        <p>RETROUVEZ-NOUS SUR:</p>
                        <ul>
                            <li>
                                <span>Address :</span>
                                <address>
                                    123 Rue El Saada Ariana <br> Tunisia
                                </address>
                            </li>
                            <li>
                                <span>Phone :</span>
                                (216) 53 88 40 67
                            </li>
                            <li>
                                <span>Email :</span>
                                Baskel@baskel.tn
                            </li>
                        </ul>
                    </div>
                    <div class=\"widget\">
                        <form class=\"tz-subcribe\">
                            <input type=\"text\" name=\"sub\" value=\"\" placeholder=\"Tapez votre Email...\">
                            <input type=\"submit\" name=\"subscribe\" value=\"Inscrivez-Vous\">
                        </form>
                    </div>
                    <div class=\"widget\">
                        <ul class=\"tz-social\">
                            <li>
                                <a class=\"fa fa-facebook\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-twitter\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-google-plus\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-tumblr\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-flickr\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-pinterest\" href=\"#\"></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--End footer left-->

                <!--Start footer right-->
                <div class=\"footer-right\">
                    <div class=\"tz-widget-clients widget\">
                        <h3 class=\"widget-title\">Avis Clients!</h3>
                        <div class=\"tz-widget-say\">
                            <img src=\"";
        // line 412
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/say.jpg"), "html", null, true);
        echo "\" alt=\"Kathy Young\">
                            <div class=\"entry-say\">
                                <p>goods services with friendly delivery and wonderful events #Baskel</p>
                                <span>Erij</span>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-4 col-sm-6\">
                            <div class=\"widget widget_nav_menu\">
                                <h3 class=\"widget-title\">SERVICES</h3>
                                <ul>
                                    <li>
                                        <a href=\"#\">Contactez-Nous</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">SAV</a>
                                    </li>

                                    <li>
                                        <a href=\"#\">Marques</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Chèques cadeaux</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"col-md-4 col-sm-6\">
                            <div class=\"widget widget_nav_menu\">
                                <h3 class=\"widget-title\">MON COMPTE</h3>
                                <ul>
                                    <li>
                                        <a href=\"#\">Compte</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Historiques</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Wishlist</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class=\"col-md-4 col-sm-6\">
                            <div class=\"widget widget_nav_menu\">
                                <h3 class=\"widget-title\">INFORMATIONS</h3>
                                <ul>
                                    <li>
                                        <a href=\"#\">Qui sommes-nous?</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">FAQ</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Contactez-nous</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Terme & Conditions</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End footer right-->

            </div>
        </div>
        <div class=\"tz-copyright\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-sm-6\">
                        <p>Copyright &copy; 2020 <a href=\"#\" target=\"_blank\">Baskel</a> par Unseen. Touts droits résérvés</p>
                    </div>
                    <div class=\"col-md-6 col-sm-6\">
                        <div class=\"pull-right\">
                                <span class=\"payments-method\">
                                    <a href=\"#\"><img src=\"";
        // line 492
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/Visa.png"), "html", null, true);
        echo "\" alt=\"visa\"></a>
                                    <a href=\"#\"><img src=\"";
        // line 493
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/Intersection.png"), "html", null, true);
        echo "\" alt=\"Intersection\"></a>
                                    <a href=\"#\"><img src=\"";
        // line 494
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/ebay.png"), "html", null, true);
        echo "\" alt=\"ebay\"></a>
                                    <a href=\"#\"><img src=\"";
        // line 495
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/Amazon.png"), "html", null, true);
        echo "\" alt=\"Amazon\"></a>
                                    <a href=\"#\"><img src=\"";
        // line 496
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/images/Discover.png"), "html", null, true);
        echo "\" alt=\"Discover\"></a>
                                </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--End Footer-->

    </div>

    </div>
    <!--End class site-->

    <script type='text/javascript' src=\"";
        // line 511
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 512
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 513
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/off-canvas.js"), "html", null, true);
        echo "\"></script>
    <!--jQuery Countdow-->
    <script type='text/javascript' src=\"";
        // line 515
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.plugin.min.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 516
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.countdown.min.js"), "html", null, true);
        echo "\"></script>
    <!--End Countdow-->
    <script type='text/javascript' src=\"";
        // line 518
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.parallax-1.1.3.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 519
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/owl.carousel.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src=\"";
        // line 520
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/custom.js"), "html", null, true);
        echo "\"></script>
    <script type='text/javascript' src='";
        // line 521
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.themepunch.tools.min.js"), "html", null, true);
        echo "'></script>
    <script type='text/javascript' src='";
        // line 522
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/jquery.themepunch.revolution.min.js"), "html", null, true);
        echo "'></script>
    <script type='text/javascript' src='";
        // line 523
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("front/js/custom-rs.js"), "html", null, true);
        echo "'></script>
    </body>
    </html>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/front/header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  764 => 523,  760 => 522,  756 => 521,  752 => 520,  748 => 519,  744 => 518,  739 => 516,  735 => 515,  730 => 513,  726 => 512,  722 => 511,  704 => 496,  700 => 495,  696 => 494,  692 => 493,  688 => 492,  605 => 412,  528 => 338,  524 => 337,  520 => 336,  516 => 335,  511 => 333,  506 => 331,  502 => 330,  492 => 322,  483 => 321,  473 => 320,  464 => 319,  450 => 313,  446 => 312,  442 => 311,  438 => 310,  434 => 309,  430 => 308,  425 => 306,  421 => 305,  416 => 303,  412 => 302,  408 => 301,  366 => 264,  287 => 188,  255 => 159,  237 => 144,  220 => 130,  194 => 107,  103 => 19,  99 => 18,  95 => 17,  91 => 16,  86 => 14,  81 => 12,  77 => 11,  66 => 2,  57 => 1,  47 => 321,  45 => 319,  41 => 317,  39 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% block head %}
<!DOCTYPE html>
<html lang=\"fr\">
<head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <title>Accueil</title>


    <link href=\"{{ asset('front/css/bootstrap.min.css') }}\" rel=\"stylesheet\" type='text/css'>
    <link href='{{ asset('front/css/font-awesome.min.css') }}' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='{{ asset('front/css/stylesheet.css') }}' rel='stylesheet' type='text/css'>

    <link href='{{ asset('front/css/owl.carousel.css') }}' rel='stylesheet' type='text/css'>
    <link href='{{ asset('front/css/owl.theme.css') }}' rel='stylesheet' type='text/css'>
    <link href=\"{{ asset('front/css/settings.css') }}\" rel=\"stylesheet\" type='text/css'>
    <link href=\"{{ asset('front/css/custom.css') }}\" rel=\"stylesheet\" type='text/css'>
    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">


</head>
<body>
<div class=\"fh5co-loader\"></div>
<!--Start class site-->

<div class=\"tz-site\">

    <!--Start id tz header-->
    <header id=\"tz-header\" class=\"bk-white\">
        <div class=\"container\">

            <!--Start class header top-->
            <div class=\"header-top\">
                <ul class=\"pull-left\">
                    <li>
                        <a href=\"#\">
                            DT
                            <span class=\"fa fa-angle-down tz-down\"></span>
                        </a>

                    </li>
                    <li>
                        <a href=\"#\">
                            Français

                            <span class=\"fa fa-angle-down tz-down\"></span>
                        </a>
                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"#\">Anglais</a>
                            </li>


                        </ul>
                    </li>
                    <li>
                        <a href=\"#\">Téléphone:   (+216) 53 88 40 67</a>
                    </li>
                </ul>
                <ul class=\"pull-right\">
                    <li>
                        <a href=\"shop-register.html\"> Compte</a>
                    </li>
                    <li>
                        <a href=\"#\">Wishlist</a>
                    </li>
                    <li>
                        <a href=\"shop-cart.html\">Panier</a>
                    </li>
                    <li>
                        <a href=\"shop-checkout.html\">Commande</a>
                    </li>
                    <li>
                        <a href=\"#\">Livraison</a>
                    </li>
                    <li class=\"tz-header-login\">
                        <a href=\"#\">Se Connecter</a>
                        <div class=\"tz-login-form\">
                            <form>
                                <p class=\"form-content\">
                                    <label for=\"username\">pseudo / Email</label>
                                    <input type=\"text\" name=\"username\" id=\"username\" value=\"\">
                                </p>
                                <p class=\"form-content\">
                                    <label for=\"password\">mot de passe</label>
                                    <input type=\"password\" name=\"username\" id=\"password\" value=\"\">
                                </p>
                                <p class=\"form-footer\">
                                    <a href=\"#\">mot de passe oublié?</a>
                                    <button type=\"submit\" class=\"pull-right button_class\">Se connecter</button>
                                </p>
                                <p class=\"form-text\">
                                    vous n'avez pas un compte? <a href=\"shop-register.html\">Inscription</a>
                                </p>
                            </form>
                        </div>
                    </li>

                </ul>
            </div>
            <!--End class header top-->

            <!--Start header content-->
            <div class=\"header-content\">
                <h3 class=\"tz-logo pull-left\"><a href=\"index.html\"><img src=\"{{ asset('front/images/logo horizontal 297px lengeth.png') }}\" alt=\"home\" /></a></h3>
                <div class=\"tz-search pull-right\">

                    <!--Start form search-->
                    <form>
                        <label class=\"select-arrow\">
                            <select name=\"category\">
                                <option value=\"\">Catégories</option>
                                <option value=\"#\">Vélos</option>
                                <option value=\"#\">Equipements</option>
                                <option value=\"#\">Vêtements</option>

                            </select>
                        </label>
                        <input type=\"text\" class=\"tz-query\" id=\"tz-query\" value=\"\" placeholder=\"Trouver un produit...\">
                        <button type=\"submit\"></button>
                    </form>
                    <!--End Form search-->

                    <!--live search-->
                    <div class=\"live-search\">
                        <ul>
                            <li>
                                <div class=\"live-img\"><img src=\"{{ asset('front/images/product-search1.jpg') }}\" alt=\"product search one\"></div>
                                <div class=\"live-search-content\">
                                    <h6><a href=\"single-product.html\">Defy Advanced</a></h6>
                                    <span class=\"live-meta\">
                                            <a href=\"single-product.html\">DT2650.00</a>
                                            <span class=\"product-color\">
                                                <i class=\"light-blue\"></i>
                                                <i class=\"orange\"></i>
                                                <i class=\"orange-dark\"></i>
                                            </span>
                                        </span>
                                </div>
                            </li>
                            <li>
                                <div class=\"live-img\"><img src=\"{{ asset('front/images/product-search2.jpg') }}\" alt=\"product search two\"></div>
                                <div class=\"live-search-content\">
                                    <h6><a href=\"single-product.html\">Defy Advanced</a></h6>
                                    <span class=\"live-meta\">
                                            <a href=\"single-product.html\">2650.00 DT</a>
                                            <span class=\"product-color\">
                                                <i class=\"light-blue\"></i>
                                                <i class=\"orange\"></i>
                                                <i class=\"blueviolet\"></i>
                                                <i class=\"orange-dark\"></i>
                                            </span>
                                        </span>
                                </div>
                            </li>
                            <li>
                                <div class=\"live-img\"><img src=\"{{ asset('front/images/p3.jpg') }}\" alt=\"product search one\"></div>
                                <div class=\"live-search-content\">
                                    <h6><a href=\"single-product.html\">Defy Advanced</a></h6>
                                    <span class=\"live-meta\">
                                            <a href=\"single-product.html\">2650.00 DT</a>
                                            <span class=\"product-color\">
                                                <i class=\"blueviolet\"></i>
                                                <i class=\"light-blue\"></i>
                                                <i class=\"orange-dark\"></i>
                                                <i class=\"orange\"></i>
                                            </span>
                                        </span>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <!--End live search-->
                </div>
            </div>
            <!--End class header content-->
        </div>

        <!--Start main menu -->
        <nav class=\"tz-menu-primary\">
            <div class=\"container\">

                <!--Main Menu-->
                <ul class=\"tz-main-menu pull-left nav-collapse\">
                    <li>
                        <a  href=\"{{  path('panier_homepage') }}\" >Accueil</a>
                    </li>


                    <li>
                        <a href=\"shop.html\">Categories</a>


                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"shop-rightsidebar.html\">Velos</a>
                            </li>
                            <li>
                                <a href=\"shop-cart.html\">Equipements</a>
                            </li>
                            <li>
                                <a href=\"shop-cart.html\">Vêtements</a>
                            </li>
                        </ul>

                    </li>

                    <li>
                        <a href=\"shop.html\">Magasin</a>
                    </li>




                    <li>
                        <a href=\"shop.html\">Location</a>




                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"shop-rightsidebar.html\">Velos</a>
                            </li>
                            <li>
                                <a href=\"shop-cart.html\">Equipements</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href=\"#\">
                            Evenements
                            <span class=\"cyan-dark\">Best off!</span>
                        </a>
                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"blog-right.html\">Courses</a>
                            </li>
                            <li>
                                <a href=\"single-blog.html\">Volantaires</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href=\"contact.html\">Contact</a>
                        <ul class=\"sub-menu\">
                            <li>
                                <a href=\"contact.html\">Reclamation</a>
                            </li>
                            <li>
                                <a href=\"RDV.html\">Rendez-vous</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!--End Main menu-->
                <div id=\"fh5co-product\">
                <!--Shop meta-->
                <ul class=\"tz-ecommerce-meta pull-right\">
                  <!-----wishlist ------>
                    <li class=\"tz-mini-cart\">
                        <a  href=\"{{  path('MyCart') }}\">  <span> <strong id=\"countItems\">{{ panier|length   }}</strong> </span></a>

                        <!--Mini cart-->


                        <!--End mini cart-->

                    </li>
                </ul>
                <!--End Shop meta-->

                <!--navigation mobi-->
                <button data-target=\".nav-collapse\" class=\"btn-navbar tz_icon_menu\" type=\"button\">
                    <i class=\"fa fa-bars\"></i>
                </button>
                <!--End navigation mobi-->
            </div>
        </nav>
        <!--End stat main menu-->

    </header>
    <!--End id tz header-->













    <!--End class site-->

    <script type='text/javascript' src=\"{{ asset('front/js/jquery.min.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/bootstrap.min.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/off-canvas.js') }}\"></script>
    <!--jQuery Countdow-->
    <script type='text/javascript' src=\"{{ asset('front/js/jquery.plugin.min.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/jquery.countdown.min.js') }}\"></script>
    <!--End Countdow-->
    <script type='text/javascript' src=\"{{ asset('front/js/jquery.parallax-1.1.3.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/owl.carousel.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/custom.js') }}\"></script>
    <script type='text/javascript' src='{{ asset('front/js/jquery.themepunch.tools.min.js') }}'></script>
    <script type='text/javascript' src='{{ asset('front/js/jquery.themepunch.revolution.min.js') }}'></script>
    <script type='text/javascript' src='{{ asset('front/js/custom-rs.js') }}'></script>
</body>
</html>
{% endblock %}


{% block container  %}
    {% endblock %}
{% block footer %}
    <!DOCTYPE html>
    <html lang=\"fr\">
    <head>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

        <title>Accueil</title>

        <link href=\"{{ asset('front/css/bootstrap.min.css') }}\" rel=\"stylesheet\" type='text/css'>
        <link href='{{ asset('front/css/font-awesome.min.css') }}' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900,300italic,400italic,700italic' rel='stylesheet' type='text/css'>
        <link href='{{ asset('front/css/stylesheet.css') }}' rel='stylesheet' type='text/css'>

        <link href='{{ asset('front/css/owl.carousel.css') }}' rel='stylesheet' type='text/css'>
        <link href='{{ asset('front/css/owl.theme.css') }}' rel='stylesheet' type='text/css'>
        <link href=\"{{ asset('front/css/settings.css') }}\" rel=\"stylesheet\" type='text/css'>
        <link href=\"{{ asset('front/css/custom.css') }}\" rel=\"stylesheet\" type='text/css'>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">


    </head>
    <body>





    <!--Start Footer-->
    <footer class=\"tz-footer\">
        <div class=\"footer-widget\">
            <div class=\"container\">

                <!--Start footer left-->
                <div class=\"footer-left\">
                    <div class=\"contact-info widget\">
                        <h3 class=\"widget-title\">Contacts:</h3>
                        <p>RETROUVEZ-NOUS SUR:</p>
                        <ul>
                            <li>
                                <span>Address :</span>
                                <address>
                                    123 Rue El Saada Ariana <br> Tunisia
                                </address>
                            </li>
                            <li>
                                <span>Phone :</span>
                                (216) 53 88 40 67
                            </li>
                            <li>
                                <span>Email :</span>
                                Baskel@baskel.tn
                            </li>
                        </ul>
                    </div>
                    <div class=\"widget\">
                        <form class=\"tz-subcribe\">
                            <input type=\"text\" name=\"sub\" value=\"\" placeholder=\"Tapez votre Email...\">
                            <input type=\"submit\" name=\"subscribe\" value=\"Inscrivez-Vous\">
                        </form>
                    </div>
                    <div class=\"widget\">
                        <ul class=\"tz-social\">
                            <li>
                                <a class=\"fa fa-facebook\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-twitter\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-google-plus\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-tumblr\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-flickr\" href=\"#\"></a>
                            </li>
                            <li>
                                <a class=\"fa fa-pinterest\" href=\"#\"></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--End footer left-->

                <!--Start footer right-->
                <div class=\"footer-right\">
                    <div class=\"tz-widget-clients widget\">
                        <h3 class=\"widget-title\">Avis Clients!</h3>
                        <div class=\"tz-widget-say\">
                            <img src=\"{{ asset('front/images/say.jpg') }}\" alt=\"Kathy Young\">
                            <div class=\"entry-say\">
                                <p>goods services with friendly delivery and wonderful events #Baskel</p>
                                <span>Erij</span>
                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-4 col-sm-6\">
                            <div class=\"widget widget_nav_menu\">
                                <h3 class=\"widget-title\">SERVICES</h3>
                                <ul>
                                    <li>
                                        <a href=\"#\">Contactez-Nous</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">SAV</a>
                                    </li>

                                    <li>
                                        <a href=\"#\">Marques</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Chèques cadeaux</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"col-md-4 col-sm-6\">
                            <div class=\"widget widget_nav_menu\">
                                <h3 class=\"widget-title\">MON COMPTE</h3>
                                <ul>
                                    <li>
                                        <a href=\"#\">Compte</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Historiques</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Wishlist</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class=\"col-md-4 col-sm-6\">
                            <div class=\"widget widget_nav_menu\">
                                <h3 class=\"widget-title\">INFORMATIONS</h3>
                                <ul>
                                    <li>
                                        <a href=\"#\">Qui sommes-nous?</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">FAQ</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Contactez-nous</a>
                                    </li>
                                    <li>
                                        <a href=\"#\">Terme & Conditions</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End footer right-->

            </div>
        </div>
        <div class=\"tz-copyright\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-6 col-sm-6\">
                        <p>Copyright &copy; 2020 <a href=\"#\" target=\"_blank\">Baskel</a> par Unseen. Touts droits résérvés</p>
                    </div>
                    <div class=\"col-md-6 col-sm-6\">
                        <div class=\"pull-right\">
                                <span class=\"payments-method\">
                                    <a href=\"#\"><img src=\"{{ asset('front/images/Visa.png') }}\" alt=\"visa\"></a>
                                    <a href=\"#\"><img src=\"{{ asset('front/images/Intersection.png') }}\" alt=\"Intersection\"></a>
                                    <a href=\"#\"><img src=\"{{ asset('front/images/ebay.png') }}\" alt=\"ebay\"></a>
                                    <a href=\"#\"><img src=\"{{ asset('front/images/Amazon.png') }}\" alt=\"Amazon\"></a>
                                    <a href=\"#\"><img src=\"{{ asset('front/images/Discover.png') }}\" alt=\"Discover\"></a>
                                </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--End Footer-->

    </div>

    </div>
    <!--End class site-->

    <script type='text/javascript' src=\"{{ asset('front/js/jquery.min.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/bootstrap.min.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/off-canvas.js') }}\"></script>
    <!--jQuery Countdow-->
    <script type='text/javascript' src=\"{{ asset('front/js/jquery.plugin.min.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/jquery.countdown.min.js') }}\"></script>
    <!--End Countdow-->
    <script type='text/javascript' src=\"{{ asset('front/js/jquery.parallax-1.1.3.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/owl.carousel.js') }}\"></script>
    <script type='text/javascript' src=\"{{ asset('front/js/custom.js') }}\"></script>
    <script type='text/javascript' src='{{ asset('front/js/jquery.themepunch.tools.min.js') }}'></script>
    <script type='text/javascript' src='{{ asset('front/js/jquery.themepunch.revolution.min.js') }}'></script>
    <script type='text/javascript' src='{{ asset('front/js/custom-rs.js') }}'></script>
    </body>
    </html>
{% endblock %}
", "default/front/header.html.twig", "C:\\wamp64\\www\\WebProjectSymfony\\Baskel\\app\\Resources\\views\\default\\front\\header.html.twig");
    }
}
